# escribe un programa que genere una matriz de tamaño 4x4 con números enteros aleatorios en el
# rango del 1 al 10.

import numpy as np

a = np.random.randint(11, size=(4, 4))

print(f"Esta es la matriz original")
print(a)
print(a.ndim)
print(a.shape)


print("*****************************************")
print("*****************************************")
sum = np.sum(a)
maximo = np.max(a)
minimo = np.min(a)
media = np.mean(a)

print(f"La suma de todos los elementos de la matriz es {sum}")
print(f"El máximo de la matriz es {maximo}")
print(f"El mìnimo de la matriz es {minimo}")
print(f"La media de la matriz es {media}")

print("*****************************************")
print("*****************************************")
print(f"Esta es la matriz original ")
print(a)
print(" ")

print(f"ESTAS SON LAS COLUMNAS ")
print("************************")
b = a[:, 0]
print(b)
sum_b = np.sum(b)
print(f"La suma de todos los elementos de la PRIMERA columna es {sum_b}")

print("*****************************************")
c = a[:, 1]
print(c)
sum_c = np.sum(c)
print(f"La suma de todos los elementos de la SEGUNDA columna es {sum_c}")

print("*****************************************")
d = a[:, 2]
print(d)
sum_d = np.sum(d)
print(f"La suma de todos los elementos de la TERCERA columna es {sum_d}")

print("*****************************************")
e = a[:, 3]
print(e)
sum_e = np.sum(e)
print(f"La suma de todos los elementos de la CUARTA columna es {sum_e}")
