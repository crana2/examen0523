# ############## LINUX  ##########################
# PARA PIP
# python3 setup.py sdist


# PARA PYINSTALLER
# pyinstaller --onefile --noconsole despliegue0523pip.py




# ##################################################
# ############## WINDOWS  ##########################
# python setup.py sdist

# PARA PYINSTALLER
# pyinstaller --onefile --icon=dibujoanimado2.ico --noconsole despliegue0523pyinstaller.py

