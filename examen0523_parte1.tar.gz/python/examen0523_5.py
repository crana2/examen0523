# crea la clase cuenta bancaria...

class CuentaBancaria:
    saldo = 0

    def __init__(self, nombre_titular):
        self.nombre_titular = nombre_titular

    def ingresar(self, cantidad):
        self.saldo += cantidad

    def retirar(self, cantidad):
        if cantidad > self.saldo:
            print("No hay suficiente saldo en la cuenta")
        else:
            self.saldo -= cantidad


cliente1 = CuentaBancaria("Wonder Spider")
cliente1.ingresar(500)
print(f"Este es el saldo del cliente1 {cliente1.saldo}")
cliente1.retirar(700)
print(f"Este es el saldo del cliente1 {cliente1.saldo}")

cliente2 = CuentaBancaria("Iron Man")
cliente2.ingresar(100)
print(f"Este es el saldo del cliente2 {cliente2.saldo}")
