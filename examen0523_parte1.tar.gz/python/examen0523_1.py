# crea una matriz aleatoria de 3x4 y cambiala a matriz de 4x3 utilizando la funcion reshape

import numpy as np


a = np.random.randint(10, size=(3, 4))

print("**************** MATRIZ 3X4 ****************")
print(a)
print(a.ndim)
print(a.shape)


print("**************** MATRIZ 4X3 ****************")
b = np.reshape(a, (4, 3))
print(b)
print(b.ndim)
print(b.shape)
