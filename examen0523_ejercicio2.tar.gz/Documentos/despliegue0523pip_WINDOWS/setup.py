from setuptools import setup

setup(
    name='calculadora0523pip',
    version='1',
    packages=[''],
    url='',
    license='GPL',
    author='conchi',
    author_email='conchi@gmail.com',
    description=''
)
