from setuptools import setup

setup(
    name='despliegue0523pip',
    version='1',
    packages=[''],
    include_package_data=True,
    package_data={
        '': ['*.jpg', '*.png', '*.gif']  # incluye los archivos de imagen en la distribucion
    },
    entry_points={
       'console_scripts': [
           'despliegue0523pip=despliegue0523pip:main'
       ]
    },
    url='https://www.despliegue0523pip.com',
    license='GPL',
    author='conchi',
    author_email='conchi@probando.com',
    description=''
)
