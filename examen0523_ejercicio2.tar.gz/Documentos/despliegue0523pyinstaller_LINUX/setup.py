from setuptools import setup

setup(
    name='calculadora_songoku',
    version='1',
    packages=[''],
    url='https:\\www.calculadora_songoku.com',
    license='GPL',
    author='conchi',
    author_email='conchi@examen0523.com',
    description=''
)
